import React from "react";
import Input from "../../../components/inputs/Input";
import TextArea from "../../../components/inputs/TextArea";
import SectionHeader from "../../../components/ResumeSections/SectionHeader";
import ProfilePhotoSelector from "../../../components/inputs/ProfilePhotoSelector";

const ProfileInfoForm = ({ data, onChange }) => {
  return (
    <div>
      <SectionHeader
        title="Profile"
        subtitle="How you introduce yourself at the top of the resume."
      />

      <ProfilePhotoSelector
        image={data?.profileImg}
        setImage={(file) => onChange("profileImg", file)}
        preview={data?.profilePreviewUrl}
        setPreview={(url) => onChange("profilePreviewUrl", url)}
      />

      <Input
        label="Full Name"
        value={data?.fullName}
        onChange={(e) => onChange("fullName", e.target.value)}
        placeholder="Jordan Lee"
      />

      <Input
        label="Designation"
        value={data?.designation}
        onChange={(e) => onChange("designation", e.target.value)}
        placeholder="Product Designer"
      />

      <TextArea
        label="Summary"
        value={data?.summary}
        onChange={(e) => onChange("summary", e.target.value)}
        placeholder="A short pitch about yourself"
      />
    </div>
  );
};

export default ProfileInfoForm;